import math

a = float(input("Введите a: "))
b = float(input("Введите b: "))
c = float(input("Введите c: "))
x = float(input("Введите x: "))
y = float(input("Введите y: "))

# ---- t1 = (1/c) * ( 1/(ax+b) + (y/c) * ln((yx+a)/(ax+b)) ) ----
if c == 0:
    print("Ошибка: c не может быть равно нулю")
elif a * x + b == 0:
    print("Ошибка: ax + b не может быть равно нулю")
else:
    ratio = (y * x + a) / (a * x + b)
    if ratio <= 0:
        print("Ошибка: аргумент ln в t1 должен быть положительным")
    else:
        t1 = (1 / c) * (1 / (a * x + b) + (y / c) * math.log(ratio))
        print(f"t1 = {t1:.2f}")

# ---- t2 = sin(ax) / (2a cos^2(x)) + (1/(2a)) * ln(tg(ax/2)) ----
if a == 0:
    print("Ошибка: a не может быть равно нулю")
elif math.cos(x) == 0:
    print("Ошибка: cos(x) = 0, t2 не определено")
else:
    tg_half = math.tan(a * x / 2)
    if tg_half <= 0:
        print("Ошибка: tg(ax/2) должен быть положительным для ln")
    else:
        t2 = math.sin(a * x) / (2 * a * math.cos(x) ** 2) + (1 / (2 * a)) * math.log(tg_half)
        print(f"t2 = {t2:.3f}")